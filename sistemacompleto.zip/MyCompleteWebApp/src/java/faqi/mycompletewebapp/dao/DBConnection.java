/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package faqi.mycompletewebapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author faqi
 */
public abstract class DBConnection {


    public Connection getMyDBConnection() throws ClassNotFoundException, SQLException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        return DriverManager.getConnection("jdbc:derby://localhost:1527/Bancoexemplo","APP","APP");
    }

}
